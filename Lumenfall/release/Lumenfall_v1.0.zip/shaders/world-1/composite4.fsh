#version 330 compatibility

#define FRAGMENT_SHADER
#define NETHER

#include "/program/composite_motionblur.glsl"
