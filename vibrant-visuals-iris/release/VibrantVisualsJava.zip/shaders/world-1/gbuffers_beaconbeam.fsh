#version 330 compatibility

#define DIM_NETHER
#define PROG_EMISSIVE

#include "/program/gbuffers.fsh"
