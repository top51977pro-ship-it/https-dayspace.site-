#version 330 compatibility

#define DIM_NETHER
#define PROG_ENTITIES

#include "/program/gbuffers.fsh"
