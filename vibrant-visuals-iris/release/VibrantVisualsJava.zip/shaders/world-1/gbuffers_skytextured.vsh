#version 330 compatibility

#define DIM_NETHER
#define PROG_SKYTEXTURED

#include "/program/gbuffers.vsh"
