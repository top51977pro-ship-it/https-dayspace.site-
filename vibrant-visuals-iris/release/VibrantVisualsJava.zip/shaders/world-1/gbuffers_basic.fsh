#version 330 compatibility

#define DIM_NETHER
#define PROG_BASIC

#include "/program/gbuffers.fsh"
