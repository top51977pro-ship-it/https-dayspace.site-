#version 330 compatibility

#define DIM_OVERWORLD
#define PROG_SKYTEXTURED

#include "/program/gbuffers.fsh"
