#version 330 compatibility

#define DIM_END
#define PROG_HAND

#include "/program/gbuffers.fsh"
