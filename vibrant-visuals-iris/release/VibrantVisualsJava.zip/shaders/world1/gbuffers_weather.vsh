#version 330 compatibility

#define DIM_END
#define PROG_WEATHER

#include "/program/gbuffers.vsh"
